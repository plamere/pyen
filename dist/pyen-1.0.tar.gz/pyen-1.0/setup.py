from distutils.core import setup

setup(
    name='pyen',
    version='1.0', 
    description='simple client for The Echo Nest',
    author="@plamere",
    author_email="paul@echonest.com",
    url='http://github.com/plamere/pyen',
    py_modules=['pyen'],)
